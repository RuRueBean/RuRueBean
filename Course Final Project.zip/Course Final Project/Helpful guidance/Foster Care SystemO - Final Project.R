### Loading libraries
library(dplyr)
library(tidyr)
library(gmodels)


### Data Wrangling

## Exiting the Foster Care System dataset
Exiting_FC = Children_exiting_foster_care_by_age_group
Exiting_FC = filter(Exiting_FC, DataFormat != 'Percent')
Exiting_FC = Exiting_FC %>% mutate(Data = as.numeric(Data))
Exiting_fc = select(Exiting_FC, c('Location', 'Age group', 'TimeFrame', 'Data'))
Exiting_age = names(Exiting_fc)[names(Exiting_fc) == "Age group"] <- "AgeGroup"
Tableau_Exiting = Exiting_fc %>% filter(Location != 'United States') # Using for Tableau graph

# Subsetting United States' Total data
Exiting_USA = Exiting_fc %>% filter((Location == 'United States') & (AgeGroup != 'Total') & (TimeFrame %in% c('2001', '2003', '2006', '2007', '2010', '2011', '2013', '2015', '2017', '2019')))
Exiting_USA1 = aggregate(Data~Location + AgeGroup, Exiting_USA, sum)

# Subsetting the 10 States' data
Exiting_States = Exiting_fc %>% filter((Location %in% c('Arizona', 'California', 'Colorado', 'Connecticut', 'Georgia', 'Indiana', 'Ohio', 'Texas', 'Utah', 'Vermont')) & (AgeGroup == 'Total') & (TimeFrame %in% c('2001', '2003', '2006', '2007', '2010', '2011', '2013', '2015', '2017', '2019')))
Exiting_States1 = aggregate(Data~Location + AgeGroup, Exiting_States, sum)
Exiting_States2 = select(Exiting_States1, c('Location', 'Data'))

## Youth incarceration dataset
Juveniles = Youth_residing_in_juvenile_detention_correctional_and_or_residential_facilities
Juveniles = Juveniles %>% mutate(Data = as.numeric(Data))
Juveniles = filter(Juveniles, DataFormat != 'Rate per 100,000')
Juveniles_IN = select(Juveniles, c('Location', 'TimeFrame', 'Data'))
Tableau_Juveniles = Juveniles_IN %>% filter(Location != 'United States') # Using for Tableau graph

# Subsetting United States' Total data
Juveniles_USA = Juveniles_IN %>% filter((Location == 'United States') & (TimeFrame %in% c('2001', '2003', '2006', '2007', '2010', '2011', '2013', '2015', '2017', '2019')))
Juveniles_USA1 = aggregate(Data~Location, Juveniles_USA, sum)

# Subsetting the 10 States' data
Juveniles_States = Juveniles_IN %>% filter((Location %in% c('Arizona', 'California', 'Colorado', 'Connecticut', 'Georgia', 'Indiana', 'Ohio', 'Texas', 'Utah', 'Vermont')) & (TimeFrame %in% c('2001', '2003', '2006', '2007', '2010', '2011', '2013', '2015', '2017', '2019')))
Juveniles_States1 = aggregate(Data~Location, Juveniles_States, sum)

### Data Analysis

## Testing Assumptions for Evaluation Question 1: "Do States with children leaving foster care have an influence on the juvenile incarceration numbers?"
CrossTable(Exiting_States2$Data, Juveniles_States1$Data, fisher=TRUE, chisq = TRUE, expected = TRUE, sresid = TRUE, format='SPSS')
# The p-value is .2313417 which is < .05, making this analysis not significant. Also no cells have any values > 5
# There is no influence from children leaving foster care by state to the incarceration numbers.
 
## Testing Assumptions for Evaluation Question 2: "Does the age group of children exiting foster care have an influence on juvenile incarceration numbers?"
Foster_USA1 = merge(Exiting_USA1, Juveniles_USA1, by=c('Location'))
Foster_test = select(Foster_USA1, c('Location', 'AgeGroup', 'Data.y'))
CrossTable(Exiting_USA3$AgeGroup, Juvenile2$Data, fisher=TRUE, chisq = TRUE, expected = TRUE, sresid = TRUE, format='SPSS')
# The p-value is .1572992, which is < .05, making this analysis not significant.  Also no cells have any values > 5
# There is no influence from children leaving foster care by age group to the incarceration numbers



Juvenile = ezacjrp_export
Juvenile1 = select(Juvenile, c('AgeGroup', 'Data'))
Juvenile1$Location = 'United States'
Juvenile1 = na.omit(Juvenile1)